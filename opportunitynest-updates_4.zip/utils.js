/**
 * Shared helpers for OpportunityNest — Supabase client, formatting, rendering, pagination.
 * 
 * SECURITY NOTE: For production, replace the hardcoded values below with environment variables:
 * - Use Vercel Environment Variables or similar
 * - Never commit real keys to version control
 * - The current values are placeholders - replace with your actual Supabase credentials
 */
window.OpportunityNest = window.OpportunityNest || {};

(function (ON) {
  // Configuration - Replace these with environment variables in production
  ON.SUPABASE_URL = "https://rveunrzbeynaizitqanx.supabase.co";
  ON.SUPABASE_PUBLISHABLE_KEY = "sb_publishable_i_Hzb5vyGZhjIXWNprJ_Tg_FJTry3DD";
  ON.SITE_URL = "https://opportunitynest.org";
  ON.PAGE_SIZE = 6;

  let supabaseClient;

  ON.COUNTRY_FLAG_WATERMARKS = {
    "Germany": '<svg viewBox="0 0 300 200" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><rect width="300" height="66.6" y="0" fill="#000000" /><rect width="300" height="66.6" y="66.6" fill="#DD0000" /><rect width="300" height="66.8" y="133.2" fill="#FFCE00" /></svg>',
    "Switzerland": '<svg viewBox="0 0 300 300" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><rect width="300" height="300" fill="#D52B1E" /><rect x="125" y="60" width="50" height="180" fill="#FFFFFF" /><rect x="60" y="125" width="180" height="50" fill="#FFFFFF" /></svg>',
    "United Kingdom": '<svg viewBox="0 0 300 200" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><rect width="300" height="200" fill="#012169" /><path d="M0 0 L300 200 M300 0 L0 200" stroke="#FFFFFF" stroke-width="34" /><path d="M0 0 L300 200 M300 0 L0 200" stroke="#C8102E" stroke-width="14" /><path d="M150 0 V200 M0 100 H300" stroke="#FFFFFF" stroke-width="56" /><path d="M150 0 V200 M0 100 H300" stroke="#C8102E" stroke-width="34" /></svg>',
    "Australia": '<svg viewBox="0 0 300 200" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><rect width="300" height="200" fill="#00008B" /><rect width="150" height="100" fill="#00008B" /><path d="M0 0 L150 100 M150 0 L0 100" stroke="#FFFFFF" stroke-width="14" /><path d="M75 0 V100 M0 50 H150" stroke="#FFFFFF" stroke-width="20" /><path d="M75 0 V100 M0 50 H150" stroke="#C8102E" stroke-width="10" /><g fill="#FFFFFF"><circle cx="225" cy="50" r="9" /><circle cx="255" cy="120" r="9" /><circle cx="225" cy="160" r="9" /><circle cx="180" cy="150" r="7" /><circle cx="245" cy="40" r="6" /></g></svg>',
    "Canada": '<svg viewBox="0 0 300 200" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><rect width="300" height="200" fill="#FFFFFF" /><rect width="75" height="200" fill="#FF0000" /><rect x="225" width="75" height="200" fill="#FF0000" /><path d="M150 35 L160 70 L185 60 L172 90 L195 92 L172 105 L182 130 L155 122 L150 145 L145 122 L118 130 L128 105 L105 92 L128 90 L115 60 L140 70 Z" fill="#FF0000" /></svg>',
    "Austria": '<svg viewBox="0 0 300 200" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><rect width="300" height="66.6" y="0" fill="#ED2939" /><rect width="300" height="66.6" y="66.6" fill="#FFFFFF" /><rect width="300" height="66.8" y="133.2" fill="#ED2939" /></svg>'
  };

  ON.GLOBAL_WATERMARK = '<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><circle cx="100" cy="100" r="92" fill="none" stroke="currentColor" stroke-width="6" /><ellipse cx="100" cy="100" rx="40" ry="92" fill="none" stroke="currentColor" stroke-width="5" /><line x1="8" y1="100" x2="192" y2="100" stroke="currentColor" stroke-width="6" /><path d="M16 65 Q100 90 184 65" fill="none" stroke="currentColor" stroke-width="5" /><path d="M16 135 Q100 110 184 135" fill="none" stroke="currentColor" stroke-width="5" /></svg>';

  ON.getCountryLandmark = (country = "") => {
    const flagSvg = ON.COUNTRY_FLAG_WATERMARKS[country];
    if (flagSvg) {
      return `<div class="card-landmark card-flag-watermark">${flagSvg}</div>`;
    }
    // "Global" and any unmapped country fall back to a neutral globe icon
    // rather than a missing or broken watermark.
    return `<div class="card-landmark card-globe-watermark">${ON.GLOBAL_WATERMARK}</div>`;
  };

  ON.COUNTRY_FLAGS = {
    "Australia": "🇦🇺",
    "Austria": "🇦🇹",
    "Canada": "🇨🇦",
    "Germany": "🇩🇪",
    "Switzerland": "🇨🇭",
    "United Kingdom": "🇬🇧",
    "United States": "🇺🇸",
    "Global": "🌍"
  };

  ON.getCountryFlag = (country = "") => ON.COUNTRY_FLAGS[country] || "🌍";

  ON.truncateDescription = (text = "", maxLength = 160) => {
    const clean = String(text).trim().replace(/\s+/g, " ");
    if (clean.length <= maxLength) return clean;
    // Cut at the last whole word before maxLength, then append an ellipsis.
    const sliced = clean.slice(0, maxLength);
    const lastSpace = sliced.lastIndexOf(" ");
    const safeCut = lastSpace > 80 ? sliced.slice(0, lastSpace) : sliced;
    return `${safeCut.replace(/[.,;:!?-]+$/, "")}…`;
  };

  ON.escapeHtml = (value = "") =>
    String(value)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");

  ON.DEADLINE_STATUS_LABELS = {
    rolling: "Rolling / Ongoing",
    varies: "Varies by Institution",
    not_announced: "Deadline Not Announced"
  };

  ON.formatDeadline = (item) => {
    // Accept either a raw date string (legacy calls) or a normalized opportunity object.
    const deadlineValue = typeof item === "object" && item !== null ? item.deadline : item;
    const status = typeof item === "object" && item !== null ? item.deadline_status : null;

    if (status && status !== "fixed") {
      return ON.DEADLINE_STATUS_LABELS[status] || "Deadline Not Announced";
    }

    if (!deadlineValue || !String(deadlineValue).trim()) {
      return "Deadline Not Announced";
    }

    const trimmed = String(deadlineValue).trim();
    const parsed = Date.parse(trimmed);
    if (Number.isNaN(parsed)) return "Deadline Not Announced";
    return new Intl.DateTimeFormat("en-GB", {
      day: "numeric",
      month: "short",
      year: "numeric"
    }).format(new Date(parsed));
  };

  ON.getDeadlineUrgency = (item) => {
    const deadlineValue = typeof item === "object" && item !== null ? item.deadline : item;
    const status = typeof item === "object" && item !== null ? item.deadline_status : null;

    if (status && status !== "fixed") return "none";
    if (!deadlineValue || !String(deadlineValue).trim()) return "none";
    const parsed = Date.parse(deadlineValue);
    if (Number.isNaN(parsed)) return "none";
    const daysUntil = Math.ceil((parsed - Date.now()) / (1000 * 60 * 60 * 24));
    if (daysUntil < 0) return "expired";
    if (daysUntil <= 7) return "urgent";
    if (daysUntil <= 30) return "soon";
    return "normal";
  };

  ON.getSupabaseClient = () => {
    if (!window.supabase) {
      throw new Error("Supabase client could not be loaded. Check the CDN script tag.");
    }
    if (!supabaseClient) {
      supabaseClient = window.supabase.createClient(ON.SUPABASE_URL, ON.SUPABASE_PUBLISHABLE_KEY);
    }
    return supabaseClient;
  };

  ON.normalizeOpportunity = (row) => ({
    id: row.id,
    type: row.type || "",
    funding: row.funding || "",
    title: row.title || "Untitled opportunity",
    country: row.country || "Not specified",
    level: row.level || "",
    field: row.field || "",
    deadline: row.deadline || "",
    deadline_status: row.deadline_status || "fixed",
    description: row.description || "No description available.",
    link: row.link || "#",
    slug: row.slug || "",
    created_at: row.created_at || ""
  });

  ON.setStatus = (element, message, isError = false) => {
    if (!element) return;
    element.textContent = message;
    element.classList.toggle("is-error", isError);
  };

  ON.updateMetaDescription = (description) => {
    if (!description) return;
    let meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute("content", description);
  };

  ON.compareOpportunities = (a, b, sortBy) => {
    if (sortBy === "title") {
      return a.title.localeCompare(b.title);
    }
    if (sortBy === "newest") {
      return (b.created_at || "").localeCompare(a.created_at || "");
    }
    // Sort by deadline: fixed dates first (soonest first), then rolling/varies items, alphabetically.
    const aHasDate = a.deadline_status === "fixed" && a.deadline;
    const bHasDate = b.deadline_status === "fixed" && b.deadline;
    if (aHasDate && bHasDate) {
      const deadlineA = Date.parse(a.deadline);
      const deadlineB = Date.parse(b.deadline);
      if (deadlineA !== deadlineB) return deadlineA - deadlineB;
      return a.title.localeCompare(b.title);
    }
    if (aHasDate && !bHasDate) return -1;
    if (!aHasDate && bHasDate) return 1;
    return a.title.localeCompare(b.title);
  };

  ON.filterOpportunities = (items, { searchTerm = "", country = "", type = "" } = {}) => {
    const query = searchTerm.trim().toLowerCase();
    return items.filter((item) => {
      const haystack = [item.title, item.country, item.field, item.description, item.type, item.funding, item.level]
        .join(" ")
        .toLowerCase();
      const matchesSearch = !query || haystack.includes(query);
      const matchesCountry = !country || item.country.toLowerCase() === country.toLowerCase();
      const matchesType = !type || item.type.toLowerCase() === type.toLowerCase();
      return matchesSearch && matchesCountry && matchesType;
    });
  };

  ON.renderOpportunityCard = (item) => {
    const detailUrl = `opportunity-detail.html?id=${encodeURIComponent(item.id)}`;
    const applyHref = item.link && item.link !== "#" ? item.link : detailUrl;
    const applyTarget = item.link && item.link !== "#" ? ' target="_blank" rel="noopener noreferrer"' : "";
    const urgency = ON.getDeadlineUrgency(item);
    const urgencyClass = urgency !== "none" ? ` deadline-${urgency}` : "";
    const whoCanApply = item.level || "Open to eligible applicants";
    const fieldLabel = item.field && item.field !== "All Fields" ? item.field : "Multiple Fields";

    return `
      <article class="live-opportunity-card compact-card">
        ${ON.getCountryLandmark(item.country)}
        <div class="opportunity-card-top">
          <p class="card-kicker">${ON.escapeHtml(item.type)} - ${ON.getCountryFlag(item.country)} ${ON.escapeHtml(item.country)}</p>
          <span class="deadline${urgencyClass}">${ON.escapeHtml(ON.formatDeadline(item))}</span>
        </div>
        <h3>${ON.escapeHtml(item.title)}</h3>
        <ul class="card-overview compact-overview">
          <li><strong>Field:</strong> ${ON.escapeHtml(fieldLabel)}</li>
          <li><strong>Who can apply:</strong> ${ON.escapeHtml(whoCanApply)}</li>
          <li><strong>Funding:</strong> ${ON.escapeHtml(item.funding || "See details")}</li>
        </ul>
        <div class="card-actions">
          <a class="button button-secondary" href="${ON.escapeHtml(detailUrl)}">View Details</a>
          <a class="button button-primary" href="${ON.escapeHtml(applyHref)}"${applyTarget}>Apply Now <span aria-hidden="true">↗</span></a>
        </div>
      </article>
    `;
  };

  ON.renderPagination = (container, pageCount, currentPage, onPageChange) => {
    if (!container) return;
    if (pageCount <= 1) {
      container.innerHTML = "";
      return;
    }

    container.innerHTML = Array.from({ length: pageCount }, (_, index) => {
      const page = index + 1;
      return `<button class="pagination-button${page === currentPage ? " is-active" : ""}" type="button" data-page="${page}" aria-label="Go to page ${page}" aria-current="${page === currentPage ? "page" : "false"}">${page}</button>`;
    }).join("");

    if (container._paginationHandler) {
      container.removeEventListener("click", container._paginationHandler);
    }

    container._paginationHandler = (event) => {
      const button = event.target.closest("[data-page]");
      if (!button) return;
      onPageChange(Number(button.dataset.page));
    };

    container.addEventListener("click", container._paginationHandler);
  };

  ON.paginate = (items, page, pageSize = ON.PAGE_SIZE) => {
    const pageCount = Math.max(1, Math.ceil(items.length / pageSize));
    const safePage = Math.min(Math.max(1, page), pageCount);
    const start = (safePage - 1) * pageSize;
    return {
      page: safePage,
      pageCount,
      items: items.slice(start, start + pageSize)
    };
  };

  ON.renderLoadingSkeleton = (count = 6) => {
    return Array.from({ length: count }, () => `
      <article class="live-opportunity-card skeleton-card" aria-hidden="true">
        <div class="opportunity-card-top">
          <div class="skeleton skeleton-kicker"></div>
          <div class="skeleton skeleton-deadline"></div>
        </div>
        <div class="skeleton skeleton-title"></div>
        <div class="skeleton skeleton-text"></div>
        <div class="skeleton skeleton-text-short"></div>
        <dl class="opportunity-meta">
          <div><div class="skeleton skeleton-meta"></div></div>
          <div><div class="skeleton skeleton-meta"></div></div>
          <div><div class="skeleton skeleton-meta"></div></div>
        </dl>
        <div class="card-actions">
          <div class="skeleton skeleton-button"></div>
          <div class="skeleton skeleton-button"></div>
        </div>
      </article>
    `).join("");
  };

  ON.renderErrorWithRetry = (message, onRetry) => {
    return `
      <div class="error-state">
        <p class="error-message">${ON.escapeHtml(message)}</p>
        <button class="button button-primary" onclick="${onRetry}">Try Again</button>
      </div>
    `;
  };

  ON.fetchUniqueCountries = async () => {
    try {
      const client = ON.getSupabaseClient();
      const { data } = await client.from("opportunities").select("country").not("country", "is", null);

      const countries = new Set();
      (data || []).forEach((row) => {
        if (row.country && row.country.trim()) {
          countries.add(row.country.trim());
        }
      });

      return Array.from(countries).sort();
    } catch (error) {
      console.error("Error fetching countries:", error);
      return [];
    }
  };

  ON.populateCountryFilter = async (selectElement) => {
    if (!selectElement) return;
    
    const countries = await ON.fetchUniqueCountries();
    
    selectElement.innerHTML = '<option value="">All</option>';
    
    countries.forEach(country => {
      const option = document.createElement("option");
      option.value = country;
      option.textContent = country;
      selectElement.appendChild(option);
    });
  };

  ON.fetchStatistics = async () => {
    try {
      const client = ON.getSupabaseClient();

      const [allResult, internshipCount] = await Promise.all([
        client.from("opportunities").select("id,country", { count: "exact" }),
        client.from("opportunities").select("id", { count: "exact", head: true }).eq("type", "Internship")
      ]);

      const countries = new Set();
      (allResult.data || []).forEach((row) => {
        if (row.country && row.country.trim()) {
          countries.add(row.country.trim());
        }
      });

      return {
        totalOpportunities: allResult.count || 0,
        totalInternships: internshipCount.count || 0,
        totalCountries: countries.size
      };
    } catch (error) {
      console.error("Error fetching statistics:", error);
      return {
        totalOpportunities: 0,
        totalInternships: 0,
        totalCountries: 0
      };
    }
  };

  ON.updateStatistics = async () => {
    const stats = await ON.fetchStatistics();
    
    const opportunitiesStat = document.querySelector('[data-stat="opportunities"]');
    const internshipsStat = document.querySelector('[data-stat="internships"]');
    const countriesStat = document.querySelector('[data-stat="countries"]');
    const internshipStatCard = document.getElementById('internship-stat-card');
    
    if (opportunitiesStat) {
      opportunitiesStat.textContent = stats.totalOpportunities.toLocaleString();
    }
    
    if (internshipsStat) {
      internshipsStat.textContent = stats.totalInternships.toLocaleString();
    }
    
    if (countriesStat) {
      countriesStat.textContent = stats.totalCountries.toLocaleString();
    }
    
    if (internshipStatCard) {
      if (stats.totalInternships === 0) {
        internshipStatCard.style.display = 'none';
      } else {
        internshipStatCard.style.display = '';
      }
    }
  };

  ON.generateAIContent = async (opportunityId) => {
    try {
      const client = ON.getSupabaseClient();
      
      // Call the Edge Function
      const { data, error } = await client.functions.invoke('generate-ai-content', {
        body: { opportunityId }
      });

      if (error) {
        console.error('Error generating AI content:', error);
        throw error;
      }

      console.log('AI content generated successfully:', data);
      return data;
    } catch (error) {
      console.error('Error in generateAIContent:', error);
      throw error;
    }
  };
})(window.OpportunityNest);
